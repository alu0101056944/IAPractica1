package practica.backend;


public interface IAlgoritmoBusqueda {

	public void buscar(Celda celdaMeta);
	
}
