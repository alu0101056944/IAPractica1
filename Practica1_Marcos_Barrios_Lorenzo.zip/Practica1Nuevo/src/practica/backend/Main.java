package practica.backend;

import practica.frontend.GUISimulador;

public class Main {

	public static void main(String args[]) {
		@SuppressWarnings("unused")
		GUISimulador gus = new GUISimulador();
	}
	
}
